public class GeneralRoom extends Room {
    public GeneralRoom(String name, int ID) {
        super(name, ID);

    }
    public GeneralRoom(){
        super();
    }

}
