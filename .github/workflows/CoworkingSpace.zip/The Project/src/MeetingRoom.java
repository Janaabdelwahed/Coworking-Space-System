public class MeetingRoom extends Room {

    public MeetingRoom(String name, int ID) {
        super(name, ID);
    }

}